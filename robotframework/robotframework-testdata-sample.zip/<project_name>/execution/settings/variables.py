##<< Variables should go here >>
## Example: USERNAME="user@user.com"
